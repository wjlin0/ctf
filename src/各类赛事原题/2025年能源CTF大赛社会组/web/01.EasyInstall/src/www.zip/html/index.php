<?php


header('Location: ./install.php');
exit;
?>